<?php
	session_start();
		if(!isset($_SESSION['email'])){
			$LogInStat = false;
		}else{
			$LogInStat = true;
		}
?>
<!DOCTYPE html>
<html>
	<head>
		<title> Home </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, intial-scale=1"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	</head>
	<body>
		<nav class="navbar navbar-default">
		  <div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#NavBarLink">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			  <ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
				<?php if($LogInStat == False) : ?>
				<li><a href="login.php">Login</a></li>
				<li><a href="register.php">Registration</a></li>
				<?php endif; ?>
				<?php if($LogInStat == True) : ?>
				<li><a href="courses.php">Courses</a></li>
				<li><a href="profile.php">Profile</a></li>
				<li><a href="Logout.php">Logout</a></li>
				<?php endif; ?>
			  </ul>
			</div>
		  </div>
		</nav>
		<div class="container">
			<h2>Welcome to the Online Class Register System</h2>
			<h3>This is the home page for the Online Class Register System</h3>
			This is a system for your school to use for students to enroll or unenroll from classes that are avaliable during Fall
			or spring semesters.
			<br><br>
			<?php if($LogInStat == False) : ?>
			<h4>If you have an account head to the login page, if not feel free to sign up using the registration page</h4>
			<?php endif; ?>
		</div>
	</body>
</html>