<!DOCTYPE html>
<html>
	<head>
		<title> Registration </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, intial-scale=1"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	</head>
	<body>
		<nav class="navbar navbar-default">
		  <div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#NavBarLink">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			  <ul class="nav navbar-nav">
				<li><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
				<li><a href="login.php">Login</a></li>
				<li class="active"><a href="register.php">Registration</a></li>
			  </ul>
			</div>
		  </div>
		</nav>
		<div class="container">
			<h2>Welcome to the Online Class Register System</h2>
			<h3>Please sign up below or login on the login page listed</h3>
			<?php
			if(isset($_POST['Submit'])){
				include 'config.php';
				executeQuery($con);
			}
			?>
			<form method="post">
			Email: <input type="text" name="formEmail"> <br> <br>
			User ID: <input type="text" name="formID"> <br> <br>
			Password: <input type="text" name="formPassword"> <br> <br>
			First Name: <input type="text" name="formFname"> <br> <br>
			Last Name: <input type="text" name="formLname"> <br> <br>
			Address: <input type="text" name="formAddress"> 
			<br> Full Address. Example: 1 Street, City, State Abbreviations, Zipcode <br> <br>
			Phone Number: <input type="text" name="formPhone"> 
			<br> Only use numbers, no dashs are needed <br> <br>
			Birthdate: <input type="text" name="formBirth">
			<br> Format: Year, Month, Day (1999-12-31) <br> <br>
			SSN: <input type="text" name="formSSN"> 
			<br> Only use numbers, no dashs are needed <br> <br>
			<input type="submit" name="Submit">
			</form>	
			<br><br>
		</div>
	</body>
</html>