<?php
	session_start();
		include 'config.php';
		
		if(isset($_POST['Submit'])){
			$user_login = filter_input(INPUT_POST, 'formEmail');
			$user_login_pass = filter_input(INPUT_POST, 'formPassword');
			
			$sql = "SELECT * FROM users WHERE email = '$user_login' limit 1";
			$result = mysqli_query($con, $sql);
			
			if($result){
				if($result && mysqli_num_rows($result) > 0){
					$user_data = mysqli_fetch_assoc($result);
					if($user_data['password'] === $user_login_pass){
						$_SESSION['email'] = $user_data['email'];
						header("Location: index.php");
					}
				}
			}
		}
		if(!isset($_SESSION['email'])){
		}else{
		}
?>
<!DOCTYPE html>
<html>
	<head>
		<title> Login </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, intial-scale=1"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	</head>
	<body>
		<nav class="navbar navbar-default">
		  <div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#NavBarLink">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			  <ul class="nav navbar-nav">
				<li><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
				<li class="active"><a href="login.php">Login</a></li>
				<li><a href="register.php">Registration</a></li>
			  </ul>
			</div>
		  </div>
		</nav>
		<div class="container">
			<h2>Welcome to the Online Class Register System</h2>
			<h3>If you have an account, login below, else you can sign up on the register page.</h3>
			<form method="post">
			Email: <input type="text" name="formEmail"> <br> <br>
			Password: <input type="text" name="formPassword"> <br> <br>
			<input type="submit" name="Submit">
			</form>	
		</div>
	</body>
</html>