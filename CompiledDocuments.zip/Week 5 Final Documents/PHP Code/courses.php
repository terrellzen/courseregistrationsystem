<?php
	session_start();
		if(!isset($_SESSION['email'])){
			$LogInStat = false;
		}else{
			$LogInStat = true;
		}
	function getUserID(&$con) {
		$email = $_SESSION['email'];
		$sql = "SELECT * FROM users WHERE email = '$email'";
		$result = mysqli_query($con, $sql);
		$user_data = mysqli_fetch_assoc($result);
		$user_id = $user_data['user_id'];	
		return $user_id;
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<title> Courses </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, intial-scale=1"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	</head>
	<body>
		<nav class="navbar navbar-default">
		  <div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#NavBarLink">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			  <ul class="nav navbar-nav">
				<li><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
				<li class="active"><a href="courses.php">Courses</a></li>
				<li><a href="profile.php">Profile</a></li>
				<li><a href="Logout.php">Logout</a></li>
			  </ul>
			</div>
		  </div>
		</nav>
		<div class="container">
			<h2>Welcome to the Online Class Register System</h2>
			<h3>This is the class register page.</h3>
			To register for a class, click the enroll button. 
			To unregister from a class you have registered for, click the unenroll button.
			<br><br>
			<?php
			if(isset($_POST['Submit11'])){
				include 'config.php';
				$user_id = getUserID($con);
				$sql = "INSERT INTO enrollment (class_id, user_id) VALUES ('101', '$user_id')";
				if ($con->query($sql) === TRUE) {
					  echo "You Have Enrolled";
					  echo "<br>";
				  } else {
					  echo "Failure Enrolling";
					  echo "<br>";
				  }
			}
			if(isset($_POST['Submit12'])){
				include 'config.php';
				$user_id = getUserID($con);
				$sql = "DELETE FROM enrollment WHERE user_id = '$user_id' AND class_id = 101";
				if ($con->query($sql) === TRUE) {
					  echo "You Have UnEnrolled";
					  echo "<br>";
				  } else {
					  echo "Failure UnEnrolling";
					  echo "<br>";
				  }
			}
			if(isset($_POST['Submit21'])){
				include 'config.php';
				$user_id = getUserID($con);
				$sql = "INSERT INTO enrollment (class_id, user_id) VALUES (110, '$user_id')";
				if ($con->query($sql) === TRUE) {
					  echo "You Have Enrolled";
					  echo "<br>";
				  } else {
					  echo "Failure Enrolling";
					  echo "<br>";
				  }
			}
			if(isset($_POST['Submit22'])){
				include 'config.php';
				$user_id = getUserID($con);
				$sql = "DELETE FROM enrollment WHERE user_id = '$user_id' AND class_id = 110";
				if ($con->query($sql) === TRUE) {
					  echo "You Have UnEnrolled";
					  echo "<br>";
				  } else {
					  echo "Failure UnEnrolling";
					  echo "<br>";
				  }
			}
			if(isset($_POST['Submit31'])){
				include 'config.php';
				$user_id = getUserID($con);
				$sql = "INSERT INTO enrollment (class_id, user_id) VALUES (102, '$user_id')";
				if ($con->query($sql) === TRUE) {
					  echo "You Have Enrolled";
					  echo "<br>";
				  } else {
					  echo "Failure Enrolling";
					  echo "<br>";
				  }
			}
			if(isset($_POST['Submit32'])){
				include 'config.php';
				$user_id = getUserID($con);
				$sql = "DELETE FROM enrollment WHERE user_id = '$user_id' AND class_id = 102";
				if ($con->query($sql) === TRUE) {
					  echo "You Have UnEnrolled";
					  echo "<br>";
				  } else {
					  echo "Failure UnEnrolling";
					  echo "<br>";
				  }
			}
			if(isset($_POST['Submit41'])){
				include 'config.php';
				$user_id = getUserID($con);
				$sql = "INSERT INTO enrollment (class_id, user_id) VALUES (120, '$user_id')";
				if ($con->query($sql) === TRUE) {
					  echo "You Have Enrolled";
					  echo "<br>";
				  } else {
					  echo "Failure Enrolling";
					  echo "<br>";
				  }
			}
			if(isset($_POST['Submit42'])){
				include 'config.php';
				$user_id = getUserID($con);
				$sql = "DELETE FROM enrollment WHERE user_id = '$user_id' AND class_id = 120";
				if ($con->query($sql) === TRUE) {
					  echo "You Have UnEnrolled";
					  echo "<br>";
				  } else {
					  echo "Failure UnEnrolling";
					  echo "<br>";
				  }
			}
			?>
			<br><br>
			<form method="post">
			Class: Development Introduction <br>
			Semester: Fall <br>
			<input type="submit" name="Submit11" value="Enroll">
			<input type="submit" name="Submit12" value="Unenroll"><br> <br>
			Class: Development Level 2 <br>
			Semester: Fall <br>
			<input type="submit" name="Submit21" value="Enroll">
			<input type="submit" name="Submit22" value="Unenroll"><br> <br>
			Class: Development Introduction <br>
			Semester: Spring <br>
			<input type="submit" name="Submit31" value="Enroll">
			<input type="submit" name="Submit32" value="Unenroll"><br> <br>
			Class: Development Level 3 <br>
			Semester: Spring <br>
			<input type="submit" name="Submit41" value="Enroll">
			<input type="submit" name="Submit42" value="Unenroll"><br> <br>
			</form>	
		</div>
	</body>
</html>