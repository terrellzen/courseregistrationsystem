<?php
	session_start();
		require 'config.php';
		if(!isset($_SESSION['email'])){
			$LogInStat = false;
		}else{
			$LogInStat = true;
		}
		
		$email = $_SESSION['email'];
		$sql = "SELECT * FROM users WHERE email = '$email'";
		$result = mysqli_query($con, $sql);
		$user_data = mysqli_fetch_assoc($result);
		$user_id = $user_data['user_id'];
		$password = $user_data['password'];
		$firstName = $user_data['firstname'];
		$lastName = $user_data['lastname'];
		$address = $user_data['address'];
		$phone = $user_data['phone_num'];
		$SSN = $user_data['SSN'];
		$birth = $user_data['birthday'];
		
?>
<!DOCTYPE html>
<html>
	<head>
		<title> Profile </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, intial-scale=1"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	</head>
	<body>
		<nav class="navbar navbar-default">
		  <div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#NavBarLink">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			  <ul class="nav navbar-nav">
				<li><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
				<?php if($LogInStat == False) : ?>
				<li><a href="login.php">Login</a></li>
				<li><a href="register.php">Registration</a></li>
				<?php endif; ?>
				<?php if($LogInStat == True) : ?>
				<li><a href="courses.php">Courses</a></li>
				<li class="active"><a href="profile.php">Profile</a></li>
				<li><a href="Logout.php">Logout</a></li>
				<?php endif; ?>
			  </ul>
			</div>
		  </div>
		</nav>
		<div class="container">
			<h2>Welcome to the Proflie Page</h2>
			<h3>Your Account Details</h3>
			<?php
			echo "Email: " . $_SESSION['email'] . "<br>";
			echo "User ID: " .$user_id. "<br>";
			echo "Password: " .$password. "<br>";
			echo "First Name: " .$firstName. "<br>";
			echo "Last Name: " .$lastName. "<br>";
			echo "Address: " .$address. "<br>";
			echo "Phone Number: " .$phone. "<br>";
			echo "SSN: " .$SSN. "<br>";
			echo "Birthday: " .$birth. "<br>";
			?>
			<br>
			<h3>Classes You Are Enrolled In</h3>
			<h4>If you want to unenroll from a class, go to the courses page and click unenroll on the class you wish to drop</h4>
			<?php
			$sql = "SELECT * FROM enrollment WHERE user_id = '$user_id'";
			$result = mysqli_query($con, $sql);
			
			if(mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_assoc($result)) {
				$class_id = $row['class_id'];
				$sql = "SELECT * FROM courses WHERE class_id = '$class_id'";
				$result2 = mysqli_query($con, $sql);
				if (mysqli_num_rows($result2) > 0) {
					while($row2 = mysqli_fetch_assoc($result2)) {
						echo "<br>Class ID: " . $row2["class_id"]. "<br>Name: " . $row2["class_name"]. "<br>Semester: " . $row2["semester"]. "<br>";
					}
				} else {
					echo "You are not Enrolled in any Classes";
				}
				}
			}
			?>
		</div>
	</body>
</html>