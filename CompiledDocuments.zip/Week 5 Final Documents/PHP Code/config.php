<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "school_system";
$con = new mysqli($servername, $username, $password, $db);

if ($con->connect_error) {
  die("Connection failed: " . $con->connect_error);
}

function executeQuery(&$con) {
	$formEmail = filter_input(INPUT_POST, 'formEmail');
	$formID = filter_input(INPUT_POST, 'formID');
	$formPassword = filter_input(INPUT_POST, 'formPassword');
	$formFname = filter_input(INPUT_POST, 'formFname');
	$formLname = filter_input(INPUT_POST, 'formLname');
	$formAddress = filter_input(INPUT_POST, 'formAddress');
	$formPhone = filter_input(INPUT_POST, 'formPhone');
	$formBirth = filter_input(INPUT_POST, 'formBirth');
	$formSSN = filter_input(INPUT_POST, "formSSN");
	
	$sql = "INSERT INTO users (email, user_id, password, phone_num, address, SSN, firstname, lastname, birthday)
	VALUES ('$formEmail', '$formID', '$formPassword', '$formPhone', '$formAddress', '$formSSN', '$formFname', '$formLname', '$formBirth')";
    if ($con->query($sql) === TRUE) {
	  echo "You Have Signed Up";
	  echo "<br>";
  } else {
	  echo "Failure signing up, username or email could be taken";
	  echo "<br>";
  }
}
?>